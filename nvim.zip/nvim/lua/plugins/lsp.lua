return {
    -- 1. Mason 管理器不变
    {
        'williamboman/mason.nvim',
        config = function()
            require('mason').setup({
                ui = {
                    icons = { package_installed = "✓", package_pending = "➜", package_uninstalled = "✗" }
                }
            })
        end,
    },

    -- 2 & 3. 将 mason-lspconfig 和 lspconfig 合并配置，解决 setup_handlers 消失的问题
    {
        'neovim/nvim-lspconfig',
        dependencies = { 
            'williamboman/mason.nvim',
            'williamboman/mason-lspconfig.nvim' 
        },
        config = function()
            local lspconfig = require('lspconfig')
            local mason_lspconfig = require('mason-lspconfig')

            -- 首先配置快捷键监听（LspAttach）
            vim.api.nvim_create_autocmd('LspAttach', {
                group = vim.api.nvim_create_augroup('UserLspConfig', {}),
                callback = function(ev)
                    local opts = { buffer = ev.buf }
                    vim.keymap.set('n', 'gD', vim.lsp.buf.declaration, opts)
                    vim.keymap.set('n', 'gd', vim.lsp.buf.definition, opts)
                    vim.keymap.set('n', 'K', vim.lsp.buf.hover, opts)
                    vim.keymap.set('n', 'gi', vim.lsp.buf.implementation, opts)
                    vim.keymap.set('n', '<leader>rn', vim.lsp.buf.rename, opts)
                    vim.keymap.set({ 'n', 'v' }, '<leader>ca', vim.lsp.buf.code_action, opts)
                    vim.keymap.set('n', 'gr', vim.lsp.buf.references, opts)
                    vim.keymap.set('n', '<leader>f', function()
                        vim.lsp.buf.format { async = true }
                    end, opts)
                end,
            })

            -- 🔄 核心修复：直接在 setup 里的 handlers 字段中定义初始化函数
            mason_lspconfig.setup({
                ensure_installed = { 'lua_ls' },
                
                handlers = {
                    -- 默认初始化函数（相当于以前的 setup_handlers）
                    function(server_name)
                        lspconfig[server_name].setup({})
                    end,
                    
                    -- 特殊针对 Lua 的配置
                    ["lua_ls"] = function()
                        lspconfig.lua_ls.setup({
                            settings = {
                                Lua = {
                                    diagnostics = {
                                        globals = { 'vim' },
                                    },
                                },
                            },
                        })
                    end,
                }
            })
        end,
    }
}
